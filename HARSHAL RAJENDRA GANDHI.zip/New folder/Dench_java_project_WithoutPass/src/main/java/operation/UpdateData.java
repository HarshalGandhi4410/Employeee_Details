package operation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import model.Employee;


@WebServlet("/UpdateData")
public class UpdateData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	EmpDao dao;
	int i;
	
    public UpdateData() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	dao =new EmpDao();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id=request.getParameter("id");
		int Id=Integer.parseInt(id);
		
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String mob=request.getParameter("mobile");
		
		String sallery=request.getParameter("sallery");
		double sal=Double.parseDouble(sallery);

		out.print("<body>");
		 out.print("<b> Employee Id "+ Id+" </b> <br>");
		 out.print("<b> Employee Name "+ name+" </b> <br>");
		 out.print("<b> Address "+ address+" </b> <br>");
		 out.print("<b> Mobile "+ mob+" </b> <br>");
		 out.print("<b> Sallery "+ sal+" </b> <br>");
		 
		 out.print("</body>");
		 
		Employee emp=new Employee(Id, name, address, mob, sal);
	
		try {
			
			i=dao.UpdateEmployee(emp);
						
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(i>=1) {
			
			 out.print("<h2>Data Update SuccessFully!!!!!</h2>");
			 }
		else {
			 out.print("<h2>Data Not Update SuccessFully!!!!!</h2>");
		}		

	
	
	}

}
