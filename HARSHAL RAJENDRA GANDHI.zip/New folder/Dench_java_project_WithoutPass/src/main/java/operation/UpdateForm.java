package operation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import model.Employee;

/**
 * Servlet implementation class UpdateForm
 */
@WebServlet("/UpdateForm")
public class UpdateForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   EmpDao dao;
   
   @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		dao=new EmpDao();
		
	}
		
    public UpdateForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String Id=request.getParameter("id");
		int id=Integer.parseInt(Id);
		
		Employee emp=null;
		try {
			
			emp=dao.getEmpById(id);
			System.out.println("Employee Data   " +emp);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		out.print(emp);
		out.print("data updateddddddddd!!!!!!!!!!!!!!!!!");

		out.print("<form action='UpdateData'>");
		out.print("ID: <input type='hidden' name='id' value="+emp.getId()+"><br>");
		out.print("NAME: <input type='text' name='name' value="+emp.getName()+"><br>");
		out.print("Address: <input type='text' name='name' value="+emp.getAddress()+"><br>");
		out.print("Mobile: <input type='text' name='name' value="+emp.getMobile()+"><br>");
		out.print("Sallery: <input type='text' name='name' value="+emp.getSallery()+"><br>");
		
		
		out.print("<input type='submit' value='UPDATE'"+">");
		out.print("</form>");


	
	}

}
