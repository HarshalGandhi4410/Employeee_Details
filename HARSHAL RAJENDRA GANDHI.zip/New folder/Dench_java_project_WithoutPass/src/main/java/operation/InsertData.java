package operation;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import model.Employee;


@WebServlet("/InsertData")
public class InsertData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EmpDao dao;
	int i;
    
    public InsertData() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	dao=new EmpDao();
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String id=request.getParameter("id");
		int eId=Integer.parseInt(id);
		String name=request.getParameter("name");
		String address=request.getParameter("address");
		String mobile=request.getParameter("mobile");
		String sallery=request.getParameter("sallery");
		double sal=Double.parseDouble(sallery);
		
		out.print("<body>");
		out.print("<b> Employee Id "+ eId+" </b> <br>");
		out.print("<b> Employee Name "+ name+" </b> <br>");
		out.print("<b> Address "+ address+" </b> <br>");
		out.print("<b> Mobile "+ mobile+" </b> <br>");
		out.print("<b> Sallery "+ sal+" </b> <br>");
	
		out.print("</body>");

		Employee emp=new Employee(eId, name, address, mobile, sal);
		
		try {
			
			i=dao.insertEmployee(emp);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		if(i>=1) {
			
			 out.print("<h1>DATA Inserted!!!!!</h1>");
		}
		else {
			out.print("<h2>DATA Not Inserted!!!!!</h2>");
			}
			RequestDispatcher rd=request.getRequestDispatcher("/ReadData");
			rd.include(request, response);
			request.getRequestDispatcher("view.jsp").include(request, response);
	

	}

}
