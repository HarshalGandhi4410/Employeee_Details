package operation;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EmpDao;
import model.Employee;


@WebServlet("/ReadData")
public class ReadData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  EmpDao dao;
  int i;
  
    public ReadData() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		dao=new EmpDao();
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();

		ArrayList<Employee> listEmp=null;
		
		try {
			listEmp=dao.DisplayEmployee();
						
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		out.print("<table>");
		 out.print("<tr>");
		 out.print("<td>| Id</td>");
		 out.print("<td>| Name</td>");
		 out.print("<td>| Address</td>");
		 out.print("<td>| Mobile</td>");
		 out.print("<td>| Sallery |</td>");

		 out.print("</tr><br>");
		 out.print("</table>");
		 
		Iterator<Employee> itr=listEmp.iterator();
		
		
		while(itr.hasNext()) {
			
			Employee emp=itr.next();
			out.print("<tr> ");	 
			 out.print("<td>| "+emp.getId()+"</td>");
			 out.print("<td>| "+emp.getName()+"</td>");
			 out.print("<td>| "+emp.getAddress()+"</td>");
			 out.print("<td>| "+emp.getMobile()+"</td>");
			 out.print("<td>| "+emp.getSallery()+"</td>");

				out.print("<td>| ");	
				
				out.print("<a href='DeleteData?id="+emp.getId()+"'>"+"Delete</a>");
				out.print("/<td> <br>");
				out.print("</tr>");
		}
		

		
	}

}
