package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Employee;
import utility.DBUtility;

public class EmpDao {
	
DBUtility db=new DBUtility();
	
	public int insertEmployee(Employee employee) throws ClassNotFoundException,SQLException{
		
		
		Connection con=db.getConnection();
		
		String sql= "insert into companytask value(?,?,?,?,?)";
		
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, employee.getId());
			ps.setString(2, employee.getName());
			ps.setString(3, employee.getAddress());
			ps.setString(4, employee.getMobile());
			ps.setDouble(5, employee.getSallery());	
			
			int i=ps.executeUpdate();
				
		if(i>=1)
		{
			return 1;
			
		}
		else {
			return 0;
		}
	}
	
	public int DeleteEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		int i = 0;
		Connection con = db.getConnection();

		String sql = "delete from companytask where id=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setInt(1, employee.getId());

			i = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		if (i >= 1) {
			return 1;
		} else {
			return 0;
		}

	}
	
public int UpdateEmployee(Employee employee) throws ClassNotFoundException,SQLException{
		
	int i=0;
		
		Connection con=db.getConnection();
		
		String sql="update companytask set name=?,  address=?,  mobile=?,  sallery=? where id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setString(1, employee.getName());
			ps.setString(2, employee.getAddress());
			ps.setString(3, employee.getMobile());
			ps.setDouble(4, employee.getSallery());	
			ps.setInt(5, employee.getId());
			
			i=ps.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
			
		}
		if(i>=1)
		{
			return 1;
			
		}
		else {
			return 0;
		}
	}

public ArrayList<Employee> DisplayEmployee() throws ClassNotFoundException, SQLException {

	ArrayList<Employee> list = new ArrayList<Employee>();

	
	Connection con= db.getConnection();
	String sql = "select * from companytask";

	PreparedStatement ps = con.prepareStatement(sql);

	ResultSet rs = ps.executeQuery();

	while (rs.next()) {
		Employee emp = new Employee();
		emp.setId(rs.getInt(1));
		emp.setName(rs.getString(2));
		emp.setAddress(rs.getString(3));
		emp.setMobile(rs.getString(4));
		emp.setSallery(rs.getDouble(5));
		list.add(emp);
	}
	rs.close();
	return list;
}

public Employee getEmpById(int id)throws ClassNotFoundException,SQLException
{
	Connection con= db.getConnection();
	String sql="select * from companytask where Id=?";
	
	Employee emp=new Employee();
	try {
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, id);
		
		ResultSet rs=ps.executeQuery();
		
		while (rs.next()) 
		{
			emp.setId(rs.getInt(1));
			emp.setName(rs.getString(2));
			emp.setAddress(rs.getString(3));
			emp.setMobile(rs.getString(4));
			emp.setSallery(rs.getDouble(5));
			
			
		
	} 
	}
		catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return emp;
	
}
}




